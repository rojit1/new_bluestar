def calculate_depreciation(amount, percentage):
    return amount*(percentage/100)