from django.contrib import admin
from .models import DiscountTable
# Register your models here.
admin.site.register(DiscountTable)