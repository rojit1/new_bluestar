from .base import urlpatterns

urlpatterns = urlpatterns
